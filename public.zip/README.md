#Run Backend
1. Run CMD- json-server --watch db.json --port 3030

#Run Frontend
1. Run CMD- npm run start