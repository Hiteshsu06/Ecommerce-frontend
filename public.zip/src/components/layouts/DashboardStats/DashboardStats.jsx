import Chart from "react-apexcharts";
import Customers from "@assets/customers.png";

const DashboardStats = () => {
  let data = {
    options: {
      chart: {
        id: "basic-bar"
      },
      xaxis: {
        categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999]
      }
    },
    series: [
      {
        name: "series-1",
        data: [30, 40, 45, 50, 49, 60, 70, 91]
      }
    ]
  }

  let linechart = {
    options: {
      chart: {
        id: "basic-bar"
      },
      xaxis: {
        categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998]
      }
    },
    series: [
      {
        name: "series-1",
        data: [30, 40, 45, 50, 49, 60, 70, 91]
      }
    ]
  }

  let donutChart = {
    options: {},
    series: [44, 55, 41, 17, 15],
    labels: ['A', 'B', 'C', 'D', 'E']
  }

  return (
    <div>
      <div className="flex gap-10">
        <div className="mt-4 flex w-[25%] bg-BgSecondaryColor border rounded border-BorderColor p-6">
          <div className="flex gap-5">
            <img src={Customers} alt="img" width="35" height="20"/>
            <div>
                <div className="font-bold">2000+</div>
                <div className="text-[0.8rem]">Total Customers</div>
            </div>
          </div>
        </div>
        <div className="mt-4 flex w-[25%] bg-BgSecondaryColor border rounded border-BorderColor p-6">
          <div className="flex gap-5">
          <img src={Customers} alt="img" width="35" height="20"/>
            <div>
                <div className="font-bold">140+</div>
                <div className="text-[0.8rem]">Total Products</div>
            </div>
          </div>
        </div>
        <div className="mt-4 flex w-[25%] bg-BgSecondaryColor border rounded border-BorderColor p-6">
          <div className="flex gap-5">
          <img src={Customers} alt="img" width="35" height="20"/>
            <div>
                <div className="font-bold">1600+</div>
                <div className="text-[0.8rem]">Total Sales</div>
            </div>
          </div>
        </div>
        <div className="mt-4 flex w-[25%] bg-BgSecondaryColor border rounded border-BorderColor p-6">
          <div className="flex gap-5">
          <img src={Customers} alt="img" width="35" height="20"/>
            <div>
                <div className="font-bold">2000+</div>
                <div className="text-[0.8rem]">Total Orders</div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Chart
          options={data.options}
          series={data.series}
          type="bar"
          width="500"
        />

        <Chart
            options={linechart.options}
            series={linechart.series}
            type="line"
            width="500"
          />

        <Chart 
            options={donutChart.options} 
            series={donutChart.series} 
            type="donut" 
            width="380" 
        />
      </div>
    </div>
  )
}

export default DashboardStats;