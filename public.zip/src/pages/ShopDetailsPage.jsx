const ShopDetailsPage = () => {
  return (
    <div>ShopDetailsPage</div>
  )
}

export default ShopDetailsPage;