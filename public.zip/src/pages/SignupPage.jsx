import Signup from '../components/Signup';

const SignupPage = () => {
  return (
    <div>
      <Signup/>
    </div>
  )
}

export default SignupPage;